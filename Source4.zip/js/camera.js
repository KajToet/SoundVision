
videoSelect.onchange = function() {
    if (testing) return;
    const videoSource = videoSelect.value;
    const constraints = {
        video: {deviceId: videoSource ? {exact: videoSource} : undefined,
                width: { min: sizew, ideal: sizew, max: sizew },
                height: { min: sizeh, ideal: sizeh },
                frameRate: { max: 60 }
               }
    };
    this.blur();
    return navigator.mediaDevices.getUserMedia(constraints).
        then(gotStream).catch(handleError);
};
videoSelect2.onchange = function() {
    if (testing) return;
    const videoSource = videoSelect2.value;
    const constraints = {
        video: {deviceId: videoSource ? {exact: videoSource} : undefined,
                width: { min: sizew, ideal: sizew, max: sizew },
                height: { min: sizeh, ideal: sizeh },
                frameRate: { max: 60 }}
    };
    this.blur();
    return navigator.mediaDevices.getUserMedia(constraints).
        then(gotStream2).catch(handleError);
};

function getStream() {
    const videoSource = videoSelect.value;
    const constraints = {
        video: {deviceId: videoSource ? {exact: videoSource} : undefined,
                width: { min: sizew, ideal: sizew, max: sizew },
                height: { min: sizeh, ideal: sizeh },
                frameRate: { max: 60 }
               }
    };
    return navigator.mediaDevices.getUserMedia(constraints).
        then(gotStream).catch(handleError);
}
function getStream2() {
    const videoSource = videoSelect2.value;
    const constraints = {
        video: {deviceId: videoSource ? {exact: videoSource} : undefined,
                width: { min: sizew, ideal: sizew, max: sizew },
                height: { min: sizeh, ideal: sizeh },
                frameRate: { max: 60 }
               }
    };
    return navigator.mediaDevices.getUserMedia(constraints).
        then(gotStream2).catch(handleError);
}

if (!testing) {
    getStream().then(getDevices).then(gotDevices);
    getStream2().then(getDevices).then(gotDevices2);
}

function getDevices() {
    var vals = navigator.mediaDevices.enumerateDevices();
    console.log(vals);
    return vals;
}

function gotDevices(deviceInfos) {
    window.deviceInfos = deviceInfos; // make available to console
    console.log('Available input and output devices:', deviceInfos);

    var pair = new Array();
    var cnt = 0;
    for (const deviceInfo of deviceInfos) {
        const option = document.createElement('option');
        option.value = deviceInfo.deviceId;
        if (deviceInfo.kind === 'videoinput') {
            option.text = deviceInfo.label || `Camera ${videoSelect.length + 1}`;
            videoSelect.appendChild(option);
            cnt++;
        }
    }

    if (cnt <= 1) {
        window.location.hash = "#testing";
    }
}

function gotDevices2(deviceInfos) {
    for (const deviceInfo of deviceInfos) {
        const option = document.createElement('option');
        option.value = deviceInfo.deviceId;
        if (deviceInfo.kind === 'videoinput') {
            option.text = deviceInfo.label || `Camera ${videoSelect2.length + 1}`;
            videoSelect2.appendChild(option);
        }
    }
}

function gotStream(stream) {
    videoSelect.selectedIndex = [...videoSelect.options].
        findIndex(option => option.text === stream.getVideoTracks()[0].label);
    videoElement.srcObject = stream;
    canvasElement.width = videoElement.videoWidth;
    canvasElement.height = videoElement.videoHeight;
}

function gotStream2(stream) {
    videoSelect2.selectedIndex = [...videoSelect2.options].
        findIndex(option => option.text === stream.getVideoTracks()[0].label);
    videoElement2.srcObject = stream;
}

function handleError(error) {
    console.error('Error: ', error);
}
