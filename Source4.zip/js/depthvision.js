
function getWhite(res, w, h) {
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
            var z = (y * w + x) * 4;
            
            var r = res[z];
            var g = res[z + 1];
            var b = res[z + 2];
            var wh = (r + g + b) / 3;

            res[z] = wh;
            res[z + 1] = wh;
            res[z + 2] = wh;
            //res[z + 3] = res[z+3];
        }
    }
}

function floodFill(w,h,res) {
    var startx = w / 2;
    var starty = h / 2;
    var queue = new Array([startx,starty]);
    
    var sumx = 0, sumy = 0, sumcnt = 0;
    while(queue.length > 0) {
        var xy = queue.pop();
        var x = xy[0];
        var y = xy[1];
        if (x < 0 || x == w || y < 0 || y == h) continue;
        
        var p = (y*w+x)*4;
        if (res[p] == 255) {
            res[p] = 128;
            sumx += x;
            sumy += y;
            sumcnt++;

        } else if (res[p] == 0 || res[p] == 128) continue;
        
        queue.push(new Array(x+1,y));
        queue.push(new Array(x-1,y));
        queue.push(new Array(x,y+1));
        queue.push(new Array(x,y-1));
    }
    setTonePosition(sumx/sumcnt-w/2, sumy/sumcnt-h/2, 1); 
}

var MAGIC = 140000.0;
var MAGIC2 = 70000.0;
var MAGIC3 = 15.0;
var MAGIC4 = 70000.0;
document.addEventListener('keydown', (e) => {
    if (e.code === "ArrowUp") {
        !e.shiftKey ? MAGIC += 1000 : MAGIC2 += 1000
    } else if (e.code === "ArrowDown") { 
        !e.shiftKey ? MAGIC -= 1000 : MAGIC2 -= 1000
    } else if (e.code == "ArrowLeft") {
        !e.shiftKey ? OCCLUSION -= 1 : MAGIC4 -= 1000
    } else if (e.code == "ArrowRight") {
        !e.shiftKey ? OCCLUSION += 1 : MAGIC4 += 1000
    }
    console.log('MAGIC = ' + MAGIC + ' MAGIC2 = ' + MAGIC2 + 'OCCLUSION = ' + OCCLUSION + ' MAGIC4 = ' + MAGIC4);
});

var switchLR = document.getElementById('switchLR');

var value1 = document.getElementById('value1');
var value2 = document.getElementById('value2');
var value3 = document.getElementById('value3');
function seeDepth(ddata, ddata1, ddata2, w, h) {
    var result = generateMap(ddata.data, switchLR.checked ? ddata1.data : ddata2.data, switchLR.checked ? ddata2.data : ddata1.data, w, h);

    if (!result) return;

    value1.innerHTML = "Result: " + result;
    value2.innerHTML = "Bound: " + MAGIC;
    value3.innerHTML = "Divide: " + MAGIC2;
    playBlip((result - MAGIC) / MAGIC2);
    //floodFill(w,h,res);
}