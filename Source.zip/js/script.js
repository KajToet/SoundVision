/*
Copyright 2017 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

'use strict';


var canvasElement = document.querySelector('#canvas');
var canvasElement2 = document.querySelector('#canvas2');
var videoElement = document.querySelector('#video');
var videoElement2 = document.querySelector('#video2');
var depthElement = document.querySelector('#depth');
var videoSelect = document.querySelector('select#videoSource');
var videoSelect2 = document.querySelector('select#videoSource2');

const ctx = canvasElement.getContext('2d');
const ctx2 = canvasElement2.getContext('2d');
var ctxd = depthElement.getContext('2d');

var testing = false;
var test = new Image(), test2 = new Image();
if (testing) {
    var cnt = 0;
    setInterval(function() {
        test.crossOrigin = "anonymous";
        test2.crossOrigin = "anonymous";
        switch(cnt) {
            case 0: test.src = "https://raw.githubusercontent.com/ugocapeto/dmag2/main/main/test/Art/view5.png";
                    test2.src = "https://raw.githubusercontent.com/ugocapeto/dmag2/main/main/test/Art/view1.png";//"https://i.imgur.com/tOnHReg.jpeg";
                    break;
            case 1: test.src = "https://i.imgur.com/H9GJQD9.jpeg";
                    test2.src = "https://i.imgur.com/tOnHReg.jpeg";
                    break;
        }
        cnt++;
        cnt %=2;
    }, 2000);
}
var sizew = 80;
var sizeh = 60;

videoSelect.onchange = function() {
  const videoSource = videoSelect.value;
  const constraints = {
    video: {deviceId: videoSource ? {exact: videoSource} : undefined,
    width: { min: sizew, ideal: sizew, max: sizew },
    height: { min: sizeh, ideal: sizeh },
    frameRate: { max: 60 }
    }
  };
  return navigator.mediaDevices.getUserMedia(constraints).
    then(gotStream).catch(handleError);
};
videoSelect2.onchange = function() {
  const videoSource = videoSelect2.value;
  const constraints = {
    video: {deviceId: videoSource ? {exact: videoSource} : undefined,
    width: { min: sizew, ideal: sizew, max: sizew },
    height: { min: sizeh, ideal: sizeh },
    frameRate: { max: 60 }}
  };
  return navigator.mediaDevices.getUserMedia(constraints).
    then(gotStream2).catch(handleError);
};

function getStream() {
  const videoSource = videoSelect.value;
  const constraints = {
    video: {deviceId: videoSource ? {exact: videoSource} : undefined,
    width: { min: sizew, ideal: sizew, max: sizew },
    height: { min: sizeh, ideal: sizeh },
    frameRate: { max: 60 }
    }
  };
  return navigator.mediaDevices.getUserMedia(constraints).
    then(gotStream).catch(handleError);
}
function getStream2() {
  const videoSource = videoSelect2.value;
  const constraints = {
    video: {deviceId: videoSource ? {exact: videoSource} : undefined,
    width: { min: sizew, ideal: sizew, max: sizew },
    height: { min: sizeh, ideal: sizeh },
    frameRate: { max: 60 }
    }
  };
  return navigator.mediaDevices.getUserMedia(constraints).
    then(gotStream2).catch(handleError);
}

getStream().then(getDevices).then(gotDevices);
getStream2().then(getDevices).then(gotDevices2);

var once = true;
function getDevices() {
    var vals = navigator.mediaDevices.enumerateDevices();
/*
    const supported = navigator.mediaDevices.getSupportedConstraints();
    console.log(supported);
    vals
        .then(function(devices) {
            var num = 0;
            devices.forEach(function(device) {
Object.getOwnPropertyDescriptor(device, 'deviceId');
                device.num = '' + num++;
                Object.defineProperty(device, 'deviceId', {
                    get: function() { return this.num; }
                });
            })
        });*/
    console.log(vals);
    return vals;
}

function gotDevices(deviceInfos) {
  window.deviceInfos = deviceInfos; // make available to console
  console.log('Available input and output devices:', deviceInfos);
    
  for (const deviceInfo of deviceInfos) {
    const option = document.createElement('option');
    option.value = deviceInfo.deviceId;
    if (deviceInfo.kind === 'videoinput') {
      option.text = deviceInfo.label || `Camera ${videoSelect.length + 1}`;
      videoSelect.appendChild(option);
    }
  }
}
function gotDevices2(deviceInfos) {
  for (const deviceInfo of deviceInfos) {
    const option = document.createElement('option');
    option.value = deviceInfo.deviceId;
    if (deviceInfo.kind === 'videoinput') {
      option.text = deviceInfo.label || `Camera ${videoSelect2.length + 1}`;
      videoSelect2.appendChild(option);
    }
  }
}

function gotStream(stream) {
  videoSelect.selectedIndex = [...videoSelect.options].
    findIndex(option => option.text === stream.getVideoTracks()[0].label);
  videoElement.srcObject = stream;
  canvasElement.width = videoElement.videoWidth;
  canvasElement.height = videoElement.videoHeight;
}
function gotStream2(stream) {
  videoSelect2.selectedIndex = [...videoSelect2.options].
    findIndex(option => option.text === stream.getVideoTracks()[0].label);
  videoElement2.srcObject = stream;
  canvasElement2.width = videoElement2.videoWidth;
  canvasElement2.height = videoElement2.videoHeight;
}

function handleError(error) {
  console.error('Error: ', error);
}

var t = Date.now();
var tt = 0;
var tcnt = 0;
requestAnimationFrame(function loop() {
    var t2 = t;
    t = Date.now();
    tcnt++;
    tt += Math.abs(t2 - t);
    if (tt > 1000) {
        console.log("FPS: " + tcnt);
        tcnt = 0;
        tt -= 1000;
    }
    
    var w, h;
    
    if (videoElement.videoWidth == 0 || videoElement2.videoWidth == 0 || 
        videoElement.videoWidth != videoElement2.videoWidth) {
        requestAnimationFrame(loop);
        return;
    }

    w = sizew;
    h = sizeh;

    canvasElement.width = w;
    canvasElement.height = h;
    canvasElement2.width = w;
    canvasElement2.height = h;
    depthElement.width = w;
    depthElement.height = h;
    var ddata, idata, idata2;
    
    ctx.drawImage(videoElement, 0, 0, w, h);
    ctx2.drawImage(videoElement2, 0, 0, w, h);
    if (testing) {
        ctx.drawImage(test, 0, 0, w, h);
        ctx2.drawImage(test2, 0, 0, w, h);
    }
    
    idata = ctx.getImageData(0, 0, w, h);
    idata2 = ctx2.getImageData(0, 0, w, h);
    ddata = ctxd.getImageData(0, 0, w, h);
    
    seeDepth(ddata, idata, idata2, w, h);  

    ctx.putImageData(idata, 0, 0);
    ctx2.putImageData(idata2, 0, 0);
    ctxd.putImageData(ddata, 0, 0);

    requestAnimationFrame(loop);
});
