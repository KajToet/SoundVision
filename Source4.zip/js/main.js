/*
Copyright 2017 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

'use strict';


var canvasElement = document.querySelector('#canvas');
var videoElement = document.querySelector('#video');
var videoElement2 = document.querySelector('#video2');
var depthElement = document.querySelector('#depth');
var videoSelect = document.querySelector('select#videoSource');
var videoSelect2 = document.querySelector('select#videoSource2');

const ctx = canvasElement.getContext('2d');
var ctxd = depthElement.getContext('2d');

var testing = location.hash == "#testing";
var test = new Image(), test2 = new Image();
if (testing) {
    var cnt = 0;
    setInterval(function() {
        test.crossOrigin = "anonymous";
        test2.crossOrigin = "anonymous";
        switch(cnt) {
            case 0: test.src = "images/image21.png";
                test2.src = "images/image22.png";
                break;
            case 1: test.src = "images/image1.png";
                    test2.src = "images/image2.png";
                    break;
            case 2: test.src = "images/image31.png";
                    test2.src = "images/image32.png";
                    break;
            case 3: test.src = "images/image41.png";
                    test2.src = "images/image42.png";
                    break;
            case 4: test.src = "images/image51.png";
                    test2.src = "images/image52.png";
                    break;
        }
        cnt++;
        cnt %=5;
    }, 2000);

} else {
}

var stereoTest = document.getElementById('stereotest');
stereoTest.checked = testing;
stereoTest.onchange = function(event) {
    if (stereoTest.checked) {
        window.location.hash = "#testing";
    } else {
        window.location.href = "";
    }
}

window.onhashchange = function() {
    window.location.reload();
};


var savingImages = 0;
document.getElementById('saveimages').onclick = function() {
    savingImages = 3;
}

var prevBatteryLevel = 100;
navigator.getBattery().then(function(battery) {
    battery.addEventListener('levelchange', function() {
        if (battery.level <= 0.2 && prevBatteryLevel > 0.2) {
            alert("Battery level low! 20% remaining.");
        }
        prevBatteryLevel = battery.level;
    })
});

var limitFpsFlip = false;
var limitFps = document.getElementById('limitfps');

var sizew = 80;
var sizeh = 60;

if ('getWakeLock' in navigator) {
  let wakeLockObj = null;
  
  navigator.getWakeLock('screen').then((wlObj) => {
    wakeLockObj = wlObj;
    let wakeLockRequest = null;
    const toggleWakeLock = () => {
      if (wakeLockRequest) {
        wakeLockRequest.cancel();
        wakeLockRequest = null;
        return;
      }
      wakeLockRequest = wakeLockObj.createRequest();
    };
    
    document.getElementById('wakelock').addEventListener('click', () => {
      toggleWakeLock();
      return console.log(
          `Wake lock is ${
          wakeLockObj.active ? 'active' : 'not active'}`);
    });
  }).catch((err) => {
    return console.error('Could not obtain wake lock', err);
  });
}

function saveUrl (url, filename) {
	var link = document.createElement("a");
	if ('download' in link) {
		link.download = filename;
		link.href = url;
		link.style.position = 'absolute';
		link.style.left = '0';
		link.style.top = '0';

		// some browsers need it to be in the document
		document.body.appendChild(link);
		link.click();
		
		setTimeout(function () {
			document.body.removeChild(link);
		}, 250);
	}
	else {
		// async callback -> window.open() will fail
		window.location = url;
	}
}

var ddata = null, idata = null, idata2 = null;
var t = Date.now();
var tt = 0;
var tcnt = 0;
var flip = false;

requestAnimationFrame(function loop() {
    if (limitFps.checked) {
        limitFpsFlip = !limitFpsFlip;
        if (limitFpsFlip) {
            requestAnimationFrame(loop);
            return;
        }
    }
    
    flip = !flip;

    if (savingImages > 0) {
        if (savingImages == 3) {
            var image = depthElement.toDataURL("image/png").replace("image/png", "image/octet-stream");
            saveUrl(image, "imaged.png");
        }else {
            var image = canvasElement.toDataURL("image/png").replace("image/png", "image/octet-stream");
            saveUrl(image, "image" + (flip ? "1" : "2") + ".png");
        }
        savingImages--;
    }
    
    var t2 = t;
    t = Date.now();
    tcnt++;
    tt += Math.abs(t2 - t);
    if (tt > 1000) {
        console.log("FPS: " + tcnt);
        document.getElementById('fps').innerHTML = "FPS: " + tcnt;
        tcnt = 0;
        tt = 0;
    }
    
    var w, h;

    if (!testing) {
        if (videoElement.videoWidth == 0 || videoElement2.videoWidth == 0 || 
            videoElement.videoWidth != videoElement2.videoWidth) {
            requestAnimationFrame(loop);
            return;
        }
    }

    w = sizew;
    h = sizeh;

    canvasElement.width = w;
    canvasElement.height = h;
    depthElement.width = w;
    depthElement.height = h;
    
    ctx.imageSmoothingEnabled = true;
    if (testing) {
        ctx.drawImage(flip ? test : test2, 0, 0, w, h);
    } else {
        ctx.drawImage(flip ? videoElement : videoElement2, 0, 0, w, h);
    }
    
    if (!flip) idata = ctx.getImageData(0, 0, w, h);
    if (flip) idata2 = ctx.getImageData(0, 0, w, h);
    
    if (idata == null || idata2 == null) {
        requestAnimationFrame(loop);
        return;
    }
    
    ddata = ctxd.getImageData(0, 0, w, h);

    seeDepth(ddata, idata, idata2, w, h);  

    if (!flip) ctx.putImageData(idata, 0, 0);
    if (flip) ctx.putImageData(idata2, 0, 0);
    ctxd.putImageData(ddata, 0, 0);

    requestAnimationFrame(loop);
});
