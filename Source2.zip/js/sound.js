

/*
var tune = [{ note: "E5", duration: "8n", timing: 0 },
{ note: "D#5", duration: "8n", timing: 0.25 },
{ note: "E5", duration: "8n", timing: 0.5 },
{ note: "D#5", duration: "8n", timing: 0.75 },
{ note: "E5", duration: "8n", timing: 1 },
{ note: "B4", duration: "8n", timing: 1.25 }];
*/

var panner = null, synth = null;

    panner = new Tone.Panner3D().toMaster()
    panner.panningModel = 'HRTF'

    synth = new Tone.Synth({
        oscillator : {
            type : 'square'
        },
        envelope : {
            attack  : 0.01,
            decay : 0.1,
            sustain : 0
        }
    }).connect(panner);


function setTonePosition(x, y) {
    if (synth == null || panner == null) return;
    
    const now = Tone.now();
    setTimeout(() => {
        try {
            panner.setPosition(x * 10, y * 10, 1);

            synth.triggerAttackRelease("E5", "8n", now + 1.25);
        } catch (e) {}

    }, 200);
}