
function getWhite(res, w, h) {
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
            var z = (y * w + x) * 4;
            
            var r = res[z];
            var g = res[z + 1];
            var b = res[z + 2];
            var wh = (r + g + b) / 3;

            res[z] = wh;
            res[z + 1] = wh;
            res[z + 2] = wh;
            res[z + 3] = res[z+3];
        }
    }
}

function floodFill(w,h,res) {
    var startx = w / 2;
    var starty = h / 2;
    var queue = new Array([startx,starty]);
    
    var sumx = 0, sumy = 0, sumcnt = 0;
    while(queue.length > 0) {
        var xy = queue.pop();
        var x = xy[0];
        var y = xy[1];
        if (x < 0 || x == w || y < 0 || y == h) continue;
        
        var p = (y*w+x)*4;
        if (res[p] == 255) {
            res[p] = 128;
            sumx += x;
            sumy += y;
            sumcnt++;

        } else if (res[p] == 0 || res[p] == 128) continue;
        
        queue.push(new Array(x+1,y));
        queue.push(new Array(x-1,y));
        queue.push(new Array(x,y+1));
        queue.push(new Array(x,y-1));
    }
    setTonePosition(sumx/sumcnt-w/2, sumy/sumcnt-h/2, 100); 
}

var MAGIC = 80.0;
var MAGIC2 = 100;
var switchFrame = false;
document.addEventListener('keydown', (e) => {
    if (e.code === "ArrowUp") {
        e.shiftKey ? MAGIC += 1 : MAGIC2 += 1
    } else if (e.code === "ArrowDown") { 
        e.shiftKey ? MAGIC -= 1 : MAGIC2 -= 1
    }
    switchFrame = MAGIC % 2 == 0;
    console.log('MAGIC = ' + MAGIC + ' MAGIC2 = ' + MAGIC2);
});

var res = null, res2 = null;
function seeDepth(ddata, ddata1, ddata2, w, h) {
    generate_map(ddata.data, switchFrame ? ddata1.data : ddata2.data, switchFrame ? ddata2.data : ddata1.data, w, h);
    var sx = 0, sy = 0, scnt = 0;
    var p = 0;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            sx += x * ddata.data[p];
            sy += y * ddata.data[p];
            scnt++;
        }
    }
    sx /= 255 * scnt;
    sy /= 255 * scnt;
    setTonePosition(sx, sy);
    //floodFill(w,h,res);
}