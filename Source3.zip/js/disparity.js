var OCCLUSION = 3.84

function sqr(a)
{
	return a * a;
}

var tmp = null;
var tmp2 = null;
function generateMap(disparity_map, left, right, w, h)
{
	var img_width = w;
	var img_height = h;
	for (var line = 0; line < img_height; line++)
	{
		var cost_matrix = new Array(img_width + 1);
		for (var i = 0; i < img_width+1; i++) cost_matrix[i] = new Array();
		
		cost_matrix[0][0] = 0.0;
		for (var i = 1; i < img_width+1; i++)
		{
			cost_matrix[i][0] = i * OCCLUSION;
			cost_matrix[0][i] = i * OCCLUSION;
		}
		for (var i = 1; i < img_width + 1; i++) 
			for (var j = 1; j < img_width + 1; j++)
			{
                var p = (img_width*line + i - 1) * 4;
				var left_pixel = left[p];
				left_pixel += left[p+1];
				left_pixel += left[p + 2];
                p = (img_width*line + j - 1) * 4;
				var right_pixel = right[p];
				right_pixel += right[p+1];
				right_pixel += right[p+2];
				
				var no_occlusion = cost_matrix[i - 1][j - 1] + 1.0/64 * sqr(right_pixel - left_pixel);
				var i_occlusion = cost_matrix[i - 1][j] + OCCLUSION;
				var j_occlusion = cost_matrix[i][j - 1] + OCCLUSION;
				cost_matrix[i][j] = Math.min(no_occlusion, i_occlusion, j_occlusion);
			}
		var i = img_width, j = img_width;
		var cost_val = cost_matrix[img_width][img_width];
		while ((i > 0) && (j > 0))
		{ 
            var p = (img_width*line + i - 1) * 4;
            var left_pixel = left[p];
            left_pixel += left[p+1];
            left_pixel += left[p + 2];
            p = (img_width*line + j - 1) * 4;
            var right_pixel = right[p];
            right_pixel += right[p+1];
            right_pixel += right[p+2];

			if (cost_matrix[i][j] == cost_matrix[i - 1][j] + OCCLUSION)
			{
				disparity_map[(img_width*line + i - 1) * 4] = 0;
				i--;
			}
			else if (cost_matrix[i][j] == cost_matrix[i][j - 1] + OCCLUSION) j--;
			else
			{
				disparity_map[(img_width*line + i - 1) * 4] = i - j;	
				cost_val -= 1.0/64 * sqr(right_pixel - left_pixel);
				i--;
				j--;
			}
		}
		
	}

    var p = 0;
    var min = 99999, max = -99999, med = 0, ct = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var c = disparity_map[p];
            c = c > MAGIC ? c : MAGIC;
            if (c < min) min = c;
            if (c > max) {
                max = c;
            }
            med += c;
            ct++;
        }
    }
    med /= ct;
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var d = disparity_map[p];
            var c = d / med * 255.0;//(d - min) * 255.0 / (max - min);
            disparity_map[p] = c;               
        }
    }
    
    p = 0;
    var offset = 1;
    var s = img_width * img_height * 4;
    if (tmp == null || tmp.length != s) tmp = new Array();
    for (var y = offset; y < img_height-offset; y++) {
        for (var x = offset; x < img_width-offset; x++) {
            var ma = 0;
            for (var dy = -offset; dy <= offset; dy++) {
                var rx = x;
                var ry = y + dy;
                var c = disparity_map[(ry * img_width + rx) * 4];
                if (c > ma) ma = c;
            }
            for (var dx = -offset; dx <= offset; dx++) {
                var rx = x + dx;
                var ry = y;
                var c = disparity_map[(ry * img_width + rx) * 4];
                if (c > ma) ma = c;
            }
            
            var p = (y * img_width + x) * 4;
            tmp[p] = ma;
            tmp[p+1] = tmp[p];
            tmp[p+2] = tmp[p];
            tmp[p+3] = 255;
        }
    }
    /*
    p = 0;
    var alpha = 0.0;
    var malpha = 1.0 - alpha;
    if (tmp2 == null || tmp2.length != s) { 
        tmp2 = new Array();
        for (var p = 0; p < tmp.length; p++) {
            tmp2[p] = tmp[p];
        }
    }
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            tmp2[p] = tmp2[p] * alpha + tmp[p] * malpha;
            tmp2[p+1] = tmp2[p];
            tmp2[p+2] = tmp2[p];
            tmp2[p+3] = 255;
        }
    }*/

    disparity_map.set(tmp);    
}