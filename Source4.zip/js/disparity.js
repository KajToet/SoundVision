var OCCLUSION = 3.84

function sqr(a)
{
	return a * a;
}

function mmin(a, b, c)
{
	if ( (a < b) && (a < c) ) return a;
	else if (b < c)	return b;
	else return c;
}

function mmax(a, b, c)
{
	if ( (a > b) && (a > c) ) return a;
	else if (b > c)	return b;
	else return c;
}

function rnd(val, dec) {
    return Math.round(val * dec) / dec;
}

function bw(r,g,b) {
    return 0.2989 * r + 0.5870 * g + 0.1140 * b;
}

// Based on:
// https://github.com/1kc2/Disparity-Map/blob/main/src/disparity.cpp

var tmp = new Array();
var tmp2 = new Array();
function generateMap(disparity_map, left, right, w, h)
{
    var cost_matrix = new Array();
    var result = 0;
    
    for (var i = 0; i < w * h * 4; i++) disparity_map[i] = 0;
    
	for (var line = 0; line < h; line++)
	{
		var cost_matrix = new Array(w+1);
		for (var i = 0; i < w+1; i++) cost_matrix[i] = new Array(w+1);
		
		cost_matrix[0][0] = 0.0;
		for (var i = 1; i < w+1; i++)
		{
			cost_matrix[i][0] = i * OCCLUSION;
			cost_matrix[0][i] = i * OCCLUSION;
		}
        for (var i = 1, p = w*line*4; i < w + 1; i++, p+=4) {
            var left_pixel = bw(left[p], left[p+1], left[p+2]);

            for (var j = 1, p2 = w*line*4; j < w + 1; j++, p2+=4) {
                var right_pixel = bw(right[p2], right[p2+1], right[p2+2]);

                var no_occlusion = cost_matrix[i - 1][j - 1] + sqr(right_pixel - left_pixel)/32.0;
                var i_occlusion = cost_matrix[i - 1][j] + OCCLUSION;
                var j_occlusion = cost_matrix[i][j - 1] + OCCLUSION;
                cost_matrix[i][j] = mmin(no_occlusion, i_occlusion, j_occlusion);
            }
        }
        var i = w, j = w;
		while ((i > 0) && (j > 0))
		{ 
			if (cost_matrix[i][j] == cost_matrix[i - 1][j] + OCCLUSION)
			{
                var p = (w*line + i - 1) * 4;

                disparity_map[p] = Math.abs(i - j);
                i--;
            }
            else if (cost_matrix[i][j] == cost_matrix[i][j - 1] + OCCLUSION) 
            {
                j--;
            } else
            {
                var p = (w*line + i - 1) * 4;

				disparity_map[p] = Math.abs(i - j);
				i--;
				j--;
			}
		}
		
	}


    
    
    var p = 0;
    var min = 99999, max = -9999;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            var c = disparity_map[p];
            if (c < min) min = c;
            if (c > max) {
                max = c;
            }
            result += c;
        }
    }
    
    p = 0;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            var d = disparity_map[p];
            var c = (d - min) * 255.0 / (max - min);//d / med * 255.0;//
            disparity_map[p] = c;               
            disparity_map[p+1] = c;               
            disparity_map[p+2] = c;               
            disparity_map[p+3] = 255;               
        }
    }

    /*
    
    var offset = 1;
    
    for (var y = offset; y < h-offset; y++) {
        for (var x = offset; x < w-offset; x++) {
            var ma = 9999;
            for (var dy = -offset; dy <= offset; dy++) {
                var rx = x;
                var ry = y + dy;
                var c = disparity_map[(ry * w + rx) * 4];
                if (c < ma) ma = c;
            }
            for (var dx = -offset; dx <= offset; dx++) {
                var rx = x + dx;
                var ry = y;
                var c = disparity_map[(ry * w + rx) * 4];
                if (c < ma) ma = c;
            }
            
            var p = (y * w + x) * 4;
            tmp[p] = ma;
            tmp[p+1] = tmp[p];
            tmp[p+2] = tmp[p];
            tmp[p+3] = 255;
        }
    }

    disparity_map.set(tmp);

    for (var y = offset; y < h-offset; y++) {
        for (var x = offset; x < w-offset; x++) {
            var ma = -9999;
            for (var dy = -offset; dy <= offset; dy++) {
                var rx = x;
                var ry = y + dy;
                var c = disparity_map[(ry * w + rx) * 4];
                if (c > ma) ma = c;
            }
            for (var dx = -offset; dx <= offset; dx++) {
                var rx = x + dx;
                var ry = y;
                var c = disparity_map[(ry * w + rx) * 4];
                if (c > ma) ma = c;
            }
            
            var p = (y * w + x) * 4;
            tmp[p] = ma;
            tmp[p+1] = tmp[p];
            tmp[p+2] = tmp[p];
            tmp[p+3] = 255;
        }
    }

    disparity_map.set(tmp);
*/
    return result;
}