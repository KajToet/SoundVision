

/*
var tune = [{ note: "E5", duration: "8n", timing: 0 },
{ note: "D#5", duration: "8n", timing: 0.25 },
{ note: "E5", duration: "8n", timing: 0.5 },
{ note: "D#5", duration: "8n", timing: 0.75 },
{ note: "E5", duration: "8n", timing: 1 },
{ note: "B4", duration: "8n", timing: 1.25 }];
*/

var au = new Array();
var aucnt = 0;
var AU_MAX = 10;
var soundSwitch = document.getElementById('soundSwitch');
soundSwitch.onchange = () => {
    if (soundSwitch.checked) {
        for (var i = 0; i < AU_MAX; i++) {
            au[i] = new Audio('sounds/blip.mp3');
            au[i].play();
        }
        runAudio();
        
        console.log('Turned on sound');
    } else {
        aud = new Array();
    }
};

var volume = 0;
function runAudio() {
    if (au.length == 0) return;

    aucnt++;
    aucnt %= AU_MAX;
    au[aucnt].volume = volume;
    au[aucnt].play();
    setTimeout(runAudio, 30.0 - volume * 30.0);
}

function playBlip(vol) {
    if (!vol) return;
    volume = Math.min(1.0, Math.max(0.0, vol));
}