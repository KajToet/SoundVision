
function getWhite(res, w, h) {
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
            var z = (y * w + x) * 4;
            
            var r = res[z];
            var g = res[z + 1];
            var b = res[z + 2];
            var wh = (r + g + b) / 3;

            res[z] = wh;
            res[z + 1] = wh;
            res[z + 2] = wh;
            res[z + 3] = res[z+3];
        }
    }
}

function floodFill(w,h,res) {
    var startx = w / 2;
    var starty = h / 2;
    var queue = new Array([startx,starty]);
    
    var sumx = 0, sumy = 0, sumcnt = 0;
    while(queue.length > 0) {
        var xy = queue.pop();
        var x = xy[0];
        var y = xy[1];
        if (x < 0 || x == w || y < 0 || y == h) continue;
        
        var p = (y*w+x)*4;
        if (res[p] == 255) {
            res[p] = 128;
            sumx += x;
            sumy += y;
            sumcnt++;

        } else if (res[p] == 0 || res[p] == 128) continue;
        
        queue.push(new Array(x+1,y));
        queue.push(new Array(x-1,y));
        queue.push(new Array(x,y+1));
        queue.push(new Array(x,y-1));
    }
    setTonePosition(sumx/sumcnt-w/2, sumy/sumcnt-h/2, 100); 
}

var MAGIC = 80.0;
var MAGIC2 = 20.0;
document.addEventListener('keydown', (e) => {
    if (e.code === "ArrowUp") {
        e.shiftKey ? MAGIC += 1 : MAGIC2 += 1
    } else if (e.code === "ArrowDown") { 
        e.shiftKey ? MAGIC -= 1 : MAGIC2 -= 1
    }
    console.log('MAGIC = ' + MAGIC + ' MAGIC2 = ' + MAGIC2);
});

var res = null, res2 = null;
function seeDepth(ddata, ddata1, ddata2, w, h) {
    
    var data1 = ddata1.data;
    var data2 = ddata2.data;

    if (res == null) res = new Uint8Array(w*h*4);
    if (res2 == null) res2 = new Uint8Array(w*h*4);
    
    var p = 0;
    var min = 999999, max = -999999;
    for (var y = 0; y < h; y++) {
        var start = y * w * 4;
        var p = start;
        for (var x = 0; x < w; x++, p+=4) {
            
            var r = data1[p];
            var g = data1[p+1];
            var b = data1[p+2];
            var rr = data2[p];
            var gg = data2[p+1];
            var bb = data2[p+2];

            var dist = (Math.abs(r - rr)/255+1) * (Math.abs(g - gg)/255+1) * (Math.abs(b - bb)/255+1);
            var val = dist;
            if (val > max) max = val;
            if (val < min) min = val;
            res[p] = val;
        }
    }
    var outer = w/20.0;
    for (var y = outer; y < h-outer; y++) {
        for (var x = outer; x < w-outer; x++) {
            var sum = 0;
            
            for (var dy = -outer; dy <= outer; dy++) {
                var ry = y + dy;
                var rx = x + outer;
                sum = Math.max(sum, res[(ry * w + rx)*4]);
            }
            for (var dy = -outer; dy <= outer; dy++) {
                var ry = y + dy;
                var rx = x - outer;
                sum = Math.max(sum, res[(ry * w + rx)*4]);
            }
            for (var dx = -outer; dx <= outer; dx++) {
                var rx = x + dx;
                var ry = y + outer;
                sum = Math.max(sum, res[(ry * w + rx)*4]);
            }
            for (var dx = -outer; dx <= outer; dx++) {
                var rx = x + dx;
                var ry = y - outer;
                sum = Math.max(sum, res[(ry * w + rx)*4]);
            }
            
            res2[(y*w+x)*4] = sum;
        }
    }
    p = 0;
    var mcnt = 0, mixy = 0, mixx = 0;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            res[p] = (res2[p] - min) * 255.0 / (max - min);
            
            if (res[p] > MAGIC) {
                res[p] = 0;
            } else {
                res[p] = 255;
            }
            res[p+1] = res[p];
            res[p+2] = res[p];
            res[p+3] = 255; 
        }
    }

    floodFill(w,h,res);
    
    //playFrequency(200, 100 * (mixy / h + 0.5), (mixx / w) + 0.5, 0.5 - (mixx / w));
    
    
    ddata.data.set(res);
}