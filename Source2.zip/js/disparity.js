var OCCLUSION = 3.84

function sqr(a)
{
	return a * a;
}

var tmp = null;
var tmp2 = null;
function generate_map(disparity_map, left, right, w, h)
{
	// Assume left and right have the exact same size
	var img_width = w;
	var img_height = h;
	//var disparity_map = new Array(img_height * img_width * 4);
	for (var line = 0; line < img_height; line++)
	{
		var cost_matrix = new Array(img_width + 1);
		for (var i = 0; i < img_width+1; i++) cost_matrix[i] = new Array(img_width + 1);
		
		cost_matrix[0][0] = 0.0;
		for (var i = 1; i < img_width+1; i++)
		{
			cost_matrix[i][0] = i * OCCLUSION;
			cost_matrix[0][i] = i * OCCLUSION;
		}
		for (var i = 1; i < img_width + 1; i++) 
			for (var j = 1; j < img_width + 1; j++)
			{
                var p = (img_width*line + i - 1) * 4;
				var left_pixel = left[p];
				left_pixel += left[p+1];
				left_pixel += left[p + 2];
                p = (img_width*line + j - 1) * 4;
				var right_pixel = right[p];
				right_pixel += right[p+1];
				right_pixel += right[p+2];
				
				var no_occlusion = cost_matrix[i - 1][j - 1] + 1.0/64 * sqr(right_pixel - left_pixel);
				var i_occlusion = cost_matrix[i - 1][j] + OCCLUSION;
				var j_occlusion = cost_matrix[i][j - 1] + OCCLUSION;
				cost_matrix[i][j] = Math.min(no_occlusion, i_occlusion, j_occlusion);
			}
		var i = img_width, j = img_width;
		var cost_val = cost_matrix[img_width][img_width];
		while ((i > 0) && (j > 0))
		{ 
            var p = (img_width*line + i - 1) * 4;
            var left_pixel = left[p];
            left_pixel += left[p+1];
            left_pixel += left[p + 2];
            p = (img_width*line + j - 1) * 4;
            var right_pixel = right[p];
            right_pixel += right[p+1];
            right_pixel += right[p+2];

			if (cost_matrix[i][j] == cost_matrix[i - 1][j] + OCCLUSION)
			{
				disparity_map[(img_width*line + i - 1) * 4] = 0;
				i--;
			}
			else if (cost_matrix[i][j] == cost_matrix[i][j - 1] + OCCLUSION) j--;
			else
			{
				disparity_map[(img_width*line + i - 1) * 4] = Math.abs(i - j);	
				cost_val -= 1.0/64 * sqr(right_pixel - left_pixel);
				i--;
				j--;
			}
		}
		
	}

    var min = 99999, max = -99999;
    var p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var c = disparity_map[p];
            if (c < min) min = c;
            if (c > max) max = c;
        }
    }
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var c = (disparity_map[p] - min) * 255.0 / (max - min);
            disparity_map[p] = c;
            disparity_map[p+1] = c;
            disparity_map[p+2] = c;
            disparity_map[p+3] = 255;
        }
    }
    
    p = 0;
    var offset = 1;
    var s = img_width * img_height * 4;
    if (tmp == null || tmp.length != s) tmp = new Array();
    for (var y = offset; y < img_height-offset; y++) {
        for (var x = offset; x < img_width-offset; x++) {

            var mi = 255;
            var ma = 0;
            var su = 0;
            var cnt = 0;
            for (var dy = -offset; dy <= offset; dy++) {
                var rx = x;
                var ry = y + dy;
                var c = disparity_map[(ry * img_width + rx) * 4];
                su+=c;
                cnt++;
                if (c < mi) mi = c;
                if (c > ma) ma = c;
            }
            for (var dx = -offset; dx <= offset; dx++) {
                var rx = x + dx;
                var ry = y;
                var c = disparity_map[(ry * img_width + rx) * 4];
                su+=c;
                cnt++;
                if (c < mi) mi = c;
                if (c > ma) ma = c;
            }
            su /= cnt;
            
            var p = (y * img_width + x) * 4;
            tmp[p] = ma;
            tmp[p+1] = ma;
            tmp[p+2] = ma;
            tmp[p+3] = 255;
        }
    }
    p = 0;
    var alpha = 0.0;
    var malpha = 1.0 - alpha;
    if (tmp2 == null || tmp2.length != s) { 
        tmp2 = new Array();
        for (var p = 0; p < tmp.length; p++) {
            tmp2[p] = tmp[p];
        }
    }
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            tmp2[p] = tmp2[p] * alpha + tmp[p] * malpha;
            tmp2[p+1] = tmp2[p];
            tmp2[p+2] = tmp2[p];
            tmp2[p+3] = 255;
        }
    }

    disparity_map.set(tmp2);    
}

/*
int main(int argc, char **argv)
{
	cv::Mat left, right;
	if (read_images(left, right, argc, argv)) return -1;
	cv::Mat disparity_img = generate_map(left, right);
	cv::normalize(disparity_img, disparity_img, 0, 255, cv::NORM_MINMAX, CV_8UC1);
	cv::fastNlMeansDenoising(disparity_img, disparity_img, 7, 7, 21);
	cv::imwrite(OUTFILE, disparity_img);
	return 0;
}*/