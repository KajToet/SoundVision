var S = 16;
var Occlusion = 3.87;


function costMap(left, y1, right, y2, w) {
    var Map = new Array()
    for (var i = 0; i < w; i++) {
        Map[i] = new Array();
        for (var j = 0; j < w; j++) {
            Map[i][j] = 0;
        }
    }

    function pixelCost(i ,j) {
        var p = (y1 * w + i) * 4;
        var r = left[p];
        var g = left[p+1];
        var b = left[p+2];
        var p2 = (y2 * w + j) * 4;
        var r2 = right[p2];
        var g2 = right[p2+1];
        var b2 = right[p2+2];
        var z1 = 0.2989 * r + 0.5870 * g + 0.1140 * b;
        var z2 = 0.2989 * r2 + 0.5870 * g2 + 0.1140 * b2;
        return sqr(z1 - z2) / (2.0 * S);
    }

    function cost(i, j) {
        if (Map[i][j] != 0) return Map[i][j];

        var a;
        if (j == 0)
            a = i * Occlusion;
        else if (i == 0)
            a = j * Occlusion;
        else {
            a = mmin(cost(i - 1, j - 1) + pixelCost(i, j),
                     cost(i, j - 1) + Occlusion,
                     cost(i - 1, j) + Occlusion);
        }
        return Math.round(a * 1000.0) / 1000.0;
    }
    
    for (var i = 1; i < w; i++) {
        Map[i][0] = cost(i, 0);
    }
    for (var i = 1; i < w; i++) {
        Map[0][i] = cost(0, i);
    }
    for (var i = 1; i < w; i++) {
        for (var j = 1; j < w; j++) {
            var a = cost(i, j);
            Map[i][j] = a;
        }
    }

    return Map;
}

function make(Floats, w) {
    var i = w - 1;
    var j = w - 1;
    var disi = new Array();
    var disj = new Array();
    for (var k = 0; k < w; k++) {
        disi[k] = 0;
        disj[k] = 0;
    }
    while (i > 0 && j > 0) {
        var match = Floats[i - 1][j - 1];
        var I_ = Floats[i - 1][j];
        var J = Floats[i][j - 1];
        if (J < I_ && J < match) {
            disj[j] = abs(i - j) * 6;
            j -= 1;
        } else if (I_ < match) {
            disi[i] = abs(i - j) * 6;
            i -= 1;
        } else {
            disi[i] = abs(i - j) * 6;
            disj[j] = abs(i - j) * 6;
            i -= 1;
            j -= 1;
        }
    }
    return new Array(disi, disj);
}

function generateMap(disparityMap, left, right, w, h) {
    for (var i = 0, p = 0; i < w * h; i++, p+=4) disparityMap[p] = 255;
    
    for (var i = 0; i < h; i++) {
        var cst = costMap(left, i, right, i, w);
        var ret = make(cst, w);
        
        var p = i * w * 4;
        for (var j = 0; j < w; j++, p+= 4) {
            var a = ret[0][j];
            disparityMap[p] = a
            disparityMap[p+1] = a;
            disparityMap[p+2] = a;
            disparityMap[p+3] = 255;
            
        }
    }
    var p = 0;
    var min = 99999, max = -99999, med = 0, ct = 0;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            var c = disparityMap[p];
            c = c > MAGIC ? c - MAGIC : 0;
            if (c < min) min = c;
            if (c > max) {
                max = c;
            }
            disparityMap[p] = c;
            med += c;
            ct++;
        }
    }
    med /= ct;
    p = 0;
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p+=4) {
            var d = disparityMap[p];
            var c = (d - min) * 255.0 / (max - min);//d / med * 255.0;//
            disparityMap[p] = c;
            disparityMap[p+1s] = c;
            disparityMap[p+2] = c;
            disparityMap[p+3] = 255;               
        }
    }
}

var OCCLUSION = 3.84

function abs(a) 
{
    return Math.abs(a);
}

function sqr(a)
{
	return a * a;
}

function mmin(a, b, c)
{
	if ( (a < b) && (a < c) ) return a;
	else if (b < c)	return b;
	else return c;
}

function mmax(a, b, c)
{
	if ( (a > b) && (a > c) ) return a;
	else if (b > c)	return b;
	else return c;
}

function bw(r,g,b) 
{
    return 0.2989 * r + 0.5870 * g + 0.1140 * b;
}

// Based on:
// https://github.com/1kc2/Disparity-Map/blob/main/src/disparity.cpp

// https://github.com/Reton2/DepthMap/blob/master/Main.py

var tmp = new Array();
var tmp2 = new Array();
var cost_matrix = new Array();
function old_generateMap(disparity_map, left, right, w, h)
{
	var img_width = w;
	var img_height = h;
	for (var line = 0; line < img_height; line++)
	{
		var cost_matrix = new Array(img_width+1);
		for (var i = 0; i < img_width+1; i++) {
            cost_matrix[i] = new Array(img_width+1);
            for (var j = 0; j < img_width+1; j++) cost_matrix[i][j] = 0.0;
        }
		cost_matrix[0][0] = 0.0;
		for (var i = 1; i < img_width+1; i++)
		{
			cost_matrix[i][0] = i * OCCLUSION;
			cost_matrix[0][i] = i * OCCLUSION;
		}
        for (var i = 1, p = img_width*line*4; i < img_width + 1; i++, p+=4) {
            var left_pixel = bw(left[p], left[p+1], left[p + 2]);

            for (var j = 1, p2 = img_width*line*4; j < img_width + 1; j++, p2+=4) {
                var right_pixel = bw(right[p2], right[p2+1], right[p2+2]);

                var no_occlusion = cost_matrix[i - 1][j - 1] + sqr(right_pixel - left_pixel)/64.0;
                var i_occlusion = cost_matrix[i - 1][j] + OCCLUSION;
                var j_occlusion = cost_matrix[i][j - 1] + OCCLUSION;
                cost_matrix[i][j] = mmin(no_occlusion, i_occlusion, j_occlusion);
            }
        }
        var i = img_width, j = img_width;
		var cost_val = cost_matrix[img_width][img_width];
		while ((i > 0) && (j > 0))
		{ 
            var p = (img_width*line + i - 1) * 4;
            var left_pixel = bw(left[p], left[p+1], left[p + 2]);
            var p2 = (img_width*line + j - 1) * 4;
            var right_pixel = bw(right[p2], right[p2+1], right[p2+2]);

			if (cost_matrix[i][j] == cost_matrix[i - 1][j] + OCCLUSION)
			{
				disparity_map[p] =  Math.abs(i - j);
				i--;
			}
			else if (cost_matrix[i][j] == cost_matrix[i][j - 1] + OCCLUSION) {
                j--;
            }else
			{
				disparity_map[p] = Math.abs(i - j);	
				cost_val -= sqr(right_pixel - left_pixel)/64.0;
				i--;
				j--;
			}
		}
		
	}

    var p = 0;
    var min = 99999, max = -99999, med = 0, ct = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var c = disparity_map[p];
            c = c > MAGIC ? c - MAGIC : 0;
            if (c < min) min = c;
            if (c > max) {
                max = c;
            }
            disparity_map[p] = c;
            med += c;
            ct++;
        }
    }
    med /= ct;
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            var d = disparity_map[p];
            var c = (d - min) * 255.0 / (max - min);//d / med * 255.0;//
            disparity_map[p] = c;               
        }
    }
    
    p = 0;
    var offset = 1;
    var s = img_width * img_height * 4;
    for (var y = offset; y < img_height-offset; y++) {
        for (var x = offset; x < img_width-offset; x++) {
            var ma = 0;
            for (var dy = -offset; dy <= offset; dy++) {
                var rx = x;
                var ry = y + dy;
                var c = disparity_map[(ry * img_width + rx) * 4];
                if (c > ma) ma = c;
            }
            for (var dx = -offset; dx <= offset; dx++) {
                var rx = x + dx;
                var ry = y;
                var c = disparity_map[(ry * img_width + rx) * 4];
                if (c > ma) ma = c;
            }
            
            var p = (y * img_width + x) * 4;
            tmp[p] = ma;
            tmp[p+1] = tmp[p];
            tmp[p+2] = tmp[p];
            tmp[p+3] = 255;
        }
    }
    /*
    p = 0;
    var alpha = 0.0;
    var malpha = 1.0 - alpha;
    if (tmp2 == null || tmp2.length != s) { 
        tmp2 = new Array();
        for (var p = 0; p < tmp.length; p++) {
            tmp2[p] = tmp[p];
        }
    }
    p = 0;
    for (var y = 0; y < img_height; y++) {
        for (var x = 0; x < img_width; x++, p+=4) {
            tmp2[p] = tmp2[p] * alpha + tmp[p] * malpha;
            tmp2[p+1] = tmp2[p];
            tmp2[p+2] = tmp2[p];
            tmp2[p+3] = 255;
        }
    }*/

    disparity_map.set(tmp);    
}